inputString = input()

if len(inputString) <= 10:
    print(inputString)
else:
    print(inputString[0:10] + '...')
