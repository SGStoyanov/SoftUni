name = input('Въведете име: ')
nameList = name.split()

print("{0}. {1}.".format(nameList[0][0], nameList[1][0]))
